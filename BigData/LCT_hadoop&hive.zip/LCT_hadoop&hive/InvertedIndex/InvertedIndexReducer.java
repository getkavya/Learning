
import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class InvertedIndexReducer extends Reducer<Text, Text, Text, Text> {

	protected void reduce(Text key, Iterable<Text> value, Context context)throws IOException, InterruptedException {
		Set <String> distinctUrls = new TreeSet<String>();
		// Iterating the list of URLs and add to set to remove duplicates
		for (Text ip : value) {
			distinctUrls.add(ip.toString());
		}
		context.write(key, new Text(distinctUrls.toString()));
	}
}