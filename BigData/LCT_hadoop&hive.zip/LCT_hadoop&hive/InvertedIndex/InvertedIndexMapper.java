
import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class InvertedIndexMapper extends Mapper<Object, Text, Text, Text> {

	protected void map(Object key, Text value, Context context)throws IOException, InterruptedException {
		// split the input string by '***' delimiter
		String lines = value.toString().trim();
		String[] fields = lines.split("\\*\\*\\*");
		// note: *** is the delimiter. If we specify ***, it would be considered as regular expression. Adding \\ as a escape character.
		String url = fields[0].trim(); // trim to remove leading and trailing spaces
        String content = fields[1].trim().replace(".","").replace(",","");
		 // replacing dot & comma in the web site content with nothing. Else, hive & hive. would be considered as different words.
		StringTokenizer words = new StringTokenizer(content," ");
		while (words.hasMoreTokens()) {
			String word = words.nextToken().toLowerCase();
			 // converting each word to lower case and set as key. else, BigData & bigdata would be considered as two diffferent words.
			context.write(new Text(word), new Text(url));
		}
	}
}