
import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

// Input data

/*
I want  a cup
of coffee in a
proper copper
coffee cup
*/

// output from splitter
/*
 (0,I want a cup)
(13,of coffee in a)
(28,proper copper)
(42,coffee cup)
*/

public class WordCountMapper extends Mapper<Object, Text, Text, IntWritable> {
// The map method will be called for each output of splitter. 
// In this case, the map method would be called 4 times, since 4 key-value pairs are out from splitter
	
	// for first call key --> 0,value --> I want a cup
	protected void map(Object key, Text value, Context context)throws IOException, InterruptedException {
		// split the input string by 'space' delimiter
		StringTokenizer words = new StringTokenizer(value.toString(), " "); // split the String "I want a cup" by space.
		// StringTokenizer returns List of words.
		//words --> [I,want, a, cup]
		while (words.hasMoreTokens()) { // Iterating the list of words and map 1 to each word to produce (key,value) 
			String word = words.nextToken(); // word --> I
			context.write(new Text(word), new IntWritable(1)); // (key,value) --> (I,1)
		}
		// end of first map call, he key,value pairs produced are --> (I,1) (want,1) (a,1) (cup,1)
	}
}

// End of map operation, the produced (key,value) pairs are
/*
(I,1) (want,1) (a,1) (cup,1)
(of,1) (coffee,1) (in,1) (a,1)
(proper,1) (copper,1)
(cofee,1) (cup,1)
*/