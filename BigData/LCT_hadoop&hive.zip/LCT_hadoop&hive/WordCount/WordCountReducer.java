

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

// The Shuffle & sort groups all the unique keys and creates the key and List of values associated with each unique key.

/*
(a,[1,1])
(coffee,[1,1])
(copper,[1])
(cup,[1,1])
(I,[1])
(in,[1])
(of,[1])
(proper,[1])
(want,[1])
*/

// The reduce method would be called for each sort&shuffle output.
// In this case, the reduce method would be called 9 times.
public class WordCountReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
    // for the first time --> key - a, value - [1,1]
	protected void reduce(Text key, Iterable<IntWritable> value, Context context)throws IOException, InterruptedException {
		int sum = 0;
		// Iterating the list of values and sum
		for (IntWritable i : value) { // [1,1] - adding all values together in the list (sum of elements in the lsit)
			sum = sum + i.get();
		} // sum --> 2
		context.write(key, new IntWritable(sum)); // setting the key as sum of elements in the list as value. (a,2)
	}
}

// The following would be the output of reducer operation
/*
(a,2)
(coffee,2)
(copper,1)
(cup,2)
(I,1)
(in,1)
(of,1)
(proper,1)
(want,1)
*/
